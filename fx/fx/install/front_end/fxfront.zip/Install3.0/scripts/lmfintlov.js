function lmfintloadlov()
{
	try
	{
		var sLine = this.CmdLineParams[0];
		var aLOV = sLine.split(",");
		var boLOV = TheApplication().GetBusObject("List Of Values");
		var bcLOV = boLOV.GetBusComp("List Of Values");
		with (bcLOV)
		{			
			ActivateField("Type");
			ActivateField("Name");
			ActivateField("Value");
			ActivateField("Active");
			ActivateField("Order By");
			ActivateField("Description");
			ActivateField("Sub Type");
			ActivateField("Parent");
			ClearToQuery();
			SetSearchSpec("Type", aLOV[0]);
			SetSearchSpec("Name", aLOV[1]);
			SetSearchSpec("Value", aLOV[2]);
			SetSearchSpec("Sub Type", aLOV[7]);
			ExecuteQuery(ForwardOnly);

			if (!FirstRecord())
				NewRecord(NewAfter);			
			SetFieldValue("Type", aLOV[0]);
			SetFieldValue("Name", aLOV[1]);
			SetFieldValue("Value", aLOV[2]);
			SetFieldValue("Active", aLOV[3]);
			SetFieldValue("Order By", aLOV[4]);
			SetFieldValue("Description", aLOV[5]);
			if (aLOV[7] != "" && aLOV[7] != null)
			{
			   var oBCPick = GetPicklistBusComp("Parent");
				with (oBCPick)
				{
					ClearToQuery();
					SetSearchSpec("Type", aLOV[6]);
					SetSearchSpec("Name", aLOV[7]);
					SetSearchSpec("Value", aLOV[8]);
					ExecuteQuery(ForwardOnly);
					if (FirstRecord())
					Pick();
				}
			}
			WriteRecord();
		}
		return "Success";
	}
	catch(e)
	{
		return "Failed" + "\n" + e;
	}
}


lmfintloadlov();