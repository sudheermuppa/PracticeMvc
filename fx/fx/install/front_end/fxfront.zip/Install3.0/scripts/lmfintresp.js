function lmfintloadresponsibility()
{
	try
	{
		var sLine = this.CmdLineParams[0];
		var aResp = sLine.split(",");
        var boResp = TheApplication().GetBusObject("Responsibility");
		var bcResp = boResp.GetBusComp("Responsibility");
		with (bcResp)
		{
			ActivateField("Name");
			ActivateField("Description");
			ActivateField("Organization");
			
			ClearToQuery();
			SetSearchSpec("Name", aResp[0]);
			ExecuteQuery(ForwardOnly);
			if(!FirstRecord())
			{
				NewRecord(NewAfter);			
				SetFieldValue("Name", aResp[0]);					
				SetFieldValue("Description", aResp[1]);			
				WriteRecord();
			}
		}
		return "Success";
	}
	catch(e)
	{
		return "Failed" + "\n" + e;
	}
}

lmfintloadresponsibility();