function lmfintloadview()
{
	try
	{
		var sLine = this.CmdLineParams[0];
		var aView = sLine.split(",");
		var boView = TheApplication().GetBusObject("View Access");
		var bcView = boView.GetBusComp("Feature Access");
    	var boResp = TheApplication().GetBusObject("Responsibility");
		var bcResp = boResp.GetBusComp("Responsibility");	

		with (bcView)
		{
			ActivateField("Name");
			ActivateField("Description");

			ClearToQuery();
			SetSearchSpec("Name", aView[1]);
			ExecuteQuery(ForwardOnly);
			if(!FirstRecord())
			{
				NewRecord(NewAfter);			
				SetFieldValue("Name", aView[1]);
				SetFieldValue("Description", aView[2]);			
				WriteRecord();
			}
			var sViewId = GetFieldValue("Id");
		}		
		with(bcResp)
		{
			ClearToQuery();
			SetSearchSpec("Name", aView[0]);
			ExecuteQuery(ForwardOnly);
			var bRecExists = FirstRecord();
			if(bRecExists)
			{
				//return "Record Already Exists";
			}
			else
			{
				NewRecord(NewAfter);			
				SetFieldValue("Name", aView[0]);					
				WriteRecord();
			}
			
			var oAssocBC = GetMVGBusComp("View").GetAssocBusComp();
			with (oAssocBC)
			{
				SetSearchExpr("[Id] = '" + sViewId + "'");
				ExecuteQuery(ForwardOnly)
				if (FirstRecord)
					Associate(NewBefore);
			}
		}
		return "Success";
	}
	catch(e)
	{
		return "Failed" + "\n" + e;
	}
}

lmfintloadview();