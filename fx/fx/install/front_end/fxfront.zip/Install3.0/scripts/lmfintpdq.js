function lmfintloadpdq()
{
	try
	{
		var sLine = this.CmdLineParams[0];
		var aPDQ = sLine.split(",");		
    	var boPDQ = TheApplication().GetBusObject("Query List");
		var bcPDQ = boPDQ.GetBusComp("Admin Query List");
		with (bcPDQ)
		{
			ActivateField("Business Object");
			ActivateField("Description");
			ActivateField("Query");
			ActivateField("Private");
			ClearToQuery();
			SetSearchSpec("Business Object", aPDQ[0]);
			SetSearchSpec("Description", aPDQ[1]);
			ExecuteQuery(ForwardOnly);
			if (!FirstRecord())
				NewRecord(NewAfter);			

			SetFieldValue("Business Object", aPDQ[0]);
			SetFieldValue("Description", aPDQ[1]);
			SetFieldValue("Query", aPDQ[2]);
			SetFieldValue("Private", "N");
			WriteRecord();	
		}
		return "Success";
	}
	catch(e)
	{
		return "Failed" + "\n" + e;
	}
}

lmfintloadpdq();